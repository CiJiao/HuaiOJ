package cn.kastner.oj.domain.enums;

public enum ContestOption {
  ENABLE,
  DISABLE,
  RESET,
  START_IN_ADVANCE,
  END_IN_ADVANCE
}
