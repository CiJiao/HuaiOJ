package cn.kastner.oj.exception;

public class RequestException extends Exception {
  public RequestException(String message) {
    super(message);
  }
}
