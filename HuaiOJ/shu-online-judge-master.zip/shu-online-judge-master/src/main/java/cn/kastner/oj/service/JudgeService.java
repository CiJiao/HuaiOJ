package cn.kastner.oj.service;

public interface JudgeService {
}
