package cn.kastner.oj.domain.security;

public enum AuthorityName {
  ROLE_USER,
  ROLE_STUFF,
  ROLE_ADMIN
}
