package cn.kastner.oj.exception;

public class HaveSuchItemException extends Exception {

  public HaveSuchItemException(String message) {
    super(message);
  }
}
