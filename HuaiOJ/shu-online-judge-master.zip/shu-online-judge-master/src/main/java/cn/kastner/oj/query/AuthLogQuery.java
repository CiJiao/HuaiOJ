package cn.kastner.oj.query;

import lombok.Data;

@Data
public class AuthLogQuery {

  String username;

  String name;

}
