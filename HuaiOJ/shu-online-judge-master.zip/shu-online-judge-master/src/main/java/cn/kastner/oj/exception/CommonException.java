package cn.kastner.oj.exception;

public class CommonException {
  public static final String COMMON_EXCEPTION = "内部错误";
}
