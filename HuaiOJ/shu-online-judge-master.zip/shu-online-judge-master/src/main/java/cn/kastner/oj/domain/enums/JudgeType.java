package cn.kastner.oj.domain.enums;

public enum JudgeType {
  IMMEDIATELY,
  DELAY
}
