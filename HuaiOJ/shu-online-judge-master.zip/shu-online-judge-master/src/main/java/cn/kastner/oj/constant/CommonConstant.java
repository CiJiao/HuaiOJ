package cn.kastner.oj.constant;

import okhttp3.MediaType;

public class CommonConstant {
  public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
  public static final String CREATE_DATE = "createDate";
}
