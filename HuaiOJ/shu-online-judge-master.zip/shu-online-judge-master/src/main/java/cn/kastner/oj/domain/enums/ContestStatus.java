package cn.kastner.oj.domain.enums;

public enum ContestStatus {
  NOT_STARTED,
  PROCESSING,
  ENDED
}
