package cn.kastner.oj.domain.enums;

public enum ContestType {
  PUBLIC,
  SECRET_WITH_PASSWORD,
  SECRET_WITHOUT_PASSWORD
}
