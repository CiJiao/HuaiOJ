package cn.kastner.oj.domain.enums;

public enum Language {
  C,
  CPP,
  JAVA,
  PYTHON2,
  PYTHON3
}
