package cn.kastner.oj.exception;

public class BusinessException extends AppException {
  public BusinessException(String message) {
    super(message);
  }
}
