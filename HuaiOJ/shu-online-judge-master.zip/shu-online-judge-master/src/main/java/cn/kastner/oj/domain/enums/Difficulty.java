package cn.kastner.oj.domain.enums;

public enum Difficulty {
  LOW,
  MEDIUM,
  HIGH
}
