package cn.kastner.oj.domain;

import lombok.Data;

@Data
public class SampleIO {

  private String input;

  private String output;

}
