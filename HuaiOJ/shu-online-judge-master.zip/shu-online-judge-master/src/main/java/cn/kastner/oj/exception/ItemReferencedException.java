package cn.kastner.oj.exception;

public class ItemReferencedException extends Exception {
  public ItemReferencedException(String message) {
    super(message);
  }
}
