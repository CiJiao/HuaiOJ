package cn.kastner.oj.constant;

public class EntityName {
  public static String PROBLEM = "problem";
  public static String CONTEST = "contest";
  public static String GROUP = "group";
}
