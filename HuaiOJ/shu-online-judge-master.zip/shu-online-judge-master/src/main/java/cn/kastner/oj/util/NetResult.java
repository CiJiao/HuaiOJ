package cn.kastner.oj.util;

import org.springframework.stereotype.Component;

@Component
public class NetResult {

  public Integer code;

  public String message;

  public Object data;
}
