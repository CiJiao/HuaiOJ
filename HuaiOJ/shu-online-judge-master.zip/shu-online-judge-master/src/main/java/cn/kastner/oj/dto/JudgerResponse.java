package cn.kastner.oj.dto;

import lombok.Data;

@Data
public class JudgerResponse {
  private final String err;
  private final String data;
}
