package cn.kastner.oj.repository.result;

public interface TagScore {
  String getTagId();

  Integer getScore();
}
