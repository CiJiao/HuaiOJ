
# Online Judge For Shanghai University
![](https://travis-ci.org/shuoj/shu-online-judge.svg?branch=master)

![Docker Cloud Automated build](https://img.shields.io/docker/cloud/automated/kastnerorz/shu-online-judge)
![Docker Cloud Build Status](https://img.shields.io/docker/cloud/build/kastnerorz/shu-online-judge)
![Docker Pulls](https://img.shields.io/docker/pulls/kastnerorz/shu-online-judge)
## API Reference
[Wiki](https://github.com/shuoj/shu-online-judge/wiki)

## Deploy

Please see [shuoj/deploy](https://github.com/shuoj/deploy).
