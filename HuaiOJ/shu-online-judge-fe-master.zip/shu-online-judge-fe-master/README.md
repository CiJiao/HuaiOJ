# 上海大学 Online Judge Frontend
[![Build Status](https://travis-ci.org/shuoj/shu-online-judge-fe.svg?branch=master)](https://travis-ci.org/shuoj/shu-online-judge-fe)


# 开发运行
1. 将`vue.config.js`中`devServer`里的`target`设置为本地的后端接口
2. `yarn / npm install`
3. `yarn / npm run serve`


# 编译部署
1. `VUE_APP_BASE_URL=https://xxxxxx npm run build`
