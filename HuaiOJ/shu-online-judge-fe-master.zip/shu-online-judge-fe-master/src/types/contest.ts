enum ContestOption {
  START_IN_ADVANCE = 'START_IN_ADVANCE',
  END_IN_ADVANCE = 'END_IN_ADVANCE',
}

export { ContestOption }
