interface RankingQuery {
  groupId?: string
  teacherId?: string
}

export { RankingQuery }
