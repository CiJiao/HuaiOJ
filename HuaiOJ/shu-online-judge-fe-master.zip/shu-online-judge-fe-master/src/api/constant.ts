const { VUE_APP_BASE_URL } = process.env
export { VUE_APP_BASE_URL }
