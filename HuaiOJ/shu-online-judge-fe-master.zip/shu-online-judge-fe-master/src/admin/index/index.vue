<template>
  <Row>
    <Col span="22" offset="1" style="padding-top: 40px">
      <h1>上海大学在线判题系统管理后台</h1>
    </Col>
    <Col span="22" offset="1" style="padding-top: 40px;text-align: left">
      <li>使用过程中如果有问题请联系负责人反映情况，感谢！！！</li>
    </Col>
  </Row>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class Admin extends Vue {}
</script>

<style lang="less" scoped></style>
