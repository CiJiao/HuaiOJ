<template>
  <div>
    <img src="../assets/loading.gif" />
  </div>
</template>
<script>
export default {
  name: 'Loading',
}
</script>
<style>
img {
  width: 100px;
  height: 100px;
  display: block;
}
</style>
